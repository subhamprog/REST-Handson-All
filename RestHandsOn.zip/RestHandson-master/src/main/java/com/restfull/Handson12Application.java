package com.restfull;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Handson12Application {

	public static void main(String[] args) {
		SpringApplication.run(Handson12Application.class, args);
	}

}
